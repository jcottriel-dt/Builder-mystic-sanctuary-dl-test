import React, { useState, useRef, useEffect } from "react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Card } from "@/components/ui/card";
import { Slider } from "@/components/ui/slider";
import { Badge } from "@/components/ui/badge";
import {
  Play,
  Pause,
  Volume2,
  VolumeX,
  ExternalLink,
  Waves,
  Music,
  Video,
  Globe,
  Loader2,
} from "lucide-react";
import { cn } from "@/lib/utils";

interface StreamPlayerProps {
  url: string;
  onUrlChange: (url: string) => void;
}

export const StreamPlayer: React.FC<StreamPlayerProps> = ({
  url,
  onUrlChange,
}) => {
  const [isPlaying, setIsPlaying] = useState(false);
  const [isLoading, setIsLoading] = useState(false);
  const [isMuted, setIsMuted] = useState(false);
  const [volume, setVolume] = useState([75]);
  const [error, setError] = useState<string | null>(null);
  const [streamType, setStreamType] = useState<"audio" | "video" | null>(null);
  const [currentTime, setCurrentTime] = useState(0);
  const [duration, setDuration] = useState(0);

  const audioRef = useRef<HTMLAudioElement>(null);
  const videoRef = useRef<HTMLVideoElement>(null);

  const detectStreamType = (url: string): "audio" | "video" => {
    const audioExtensions = /\.(mp3|wav|ogg|aac|m4a|flac)(\?.*)?$/i;
    const videoExtensions = /\.(mp4|webm|ogg|mov|avi|mkv|m4v)(\?.*)?$/i;

    if (audioExtensions.test(url)) return "audio";
    if (videoExtensions.test(url)) return "video";

    // Default to audio for streaming URLs
    return "audio";
  };

  const handlePlay = async () => {
    if (!url.trim()) {
      setError("Please enter a valid streaming URL");
      return;
    }

    setError(null);
    setIsLoading(true);

    const type = detectStreamType(url);
    setStreamType(type);

    try {
      const mediaElement =
        type === "video" ? videoRef.current : audioRef.current;

      if (mediaElement) {
        mediaElement.src = url;
        mediaElement.volume = volume[0] / 100;

        await mediaElement.play();
        setIsPlaying(true);
      }
    } catch (err) {
      setError("Failed to load stream. Please check the URL and try again.");
      console.error("Stream error:", err);
    } finally {
      setIsLoading(false);
    }
  };

  const handlePause = () => {
    const mediaElement =
      streamType === "video" ? videoRef.current : audioRef.current;
    mediaElement?.pause();
    setIsPlaying(false);
  };

  const handleVolumeChange = (newVolume: number[]) => {
    setVolume(newVolume);
    const mediaElement =
      streamType === "video" ? videoRef.current : audioRef.current;
    if (mediaElement) {
      mediaElement.volume = newVolume[0] / 100;
    }
  };

  const toggleMute = () => {
    const mediaElement =
      streamType === "video" ? videoRef.current : audioRef.current;
    if (mediaElement) {
      mediaElement.muted = !isMuted;
      setIsMuted(!isMuted);
    }
  };

  const formatTime = (time: number) => {
    const minutes = Math.floor(time / 60);
    const seconds = Math.floor(time % 60);
    return `${minutes}:${seconds.toString().padStart(2, "0")}`;
  };

  const handleTimeUpdate = (e: React.SyntheticEvent<HTMLMediaElement>) => {
    const media = e.currentTarget;
    setCurrentTime(media.currentTime);
    setDuration(media.duration || 0);
  };

  return (
    <div className="w-full max-w-2xl mx-auto space-y-6">
      {/* URL Input */}
      <Card className="p-6 glass-effect streaming-glow">
        <div className="space-y-4">
          <div className="flex items-center gap-2">
            <Globe className="h-5 w-5 text-stream-600" />
            <h3 className="text-lg font-semibold gradient-text">Stream URL</h3>
          </div>

          <div className="flex gap-2">
            <Input
              placeholder="Enter streaming URL (audio/video)..."
              value={url}
              onChange={(e) => onUrlChange(e.target.value)}
              className="flex-1"
            />
            <Button
              onClick={isPlaying ? handlePause : handlePlay}
              disabled={isLoading || !url.trim()}
              className="bg-gradient-to-r from-stream-600 to-ocean-600 hover:from-stream-700 hover:to-ocean-700 px-6"
            >
              {isLoading ? (
                <Loader2 className="h-4 w-4 animate-spin" />
              ) : isPlaying ? (
                <Pause className="h-4 w-4" />
              ) : (
                <Play className="h-4 w-4" />
              )}
            </Button>
          </div>

          {error && (
            <div className="p-3 bg-red-50 border border-red-200 rounded-lg text-red-700 text-sm">
              {error}
            </div>
          )}
        </div>
      </Card>

      {/* Media Player */}
      {streamType && (
        <Card className="p-6 glass-effect streaming-glow">
          <div className="space-y-4">
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-2">
                {streamType === "video" ? (
                  <Video className="h-5 w-5 text-stream-600" />
                ) : (
                  <Music className="h-5 w-5 text-stream-600" />
                )}
                <h3 className="text-lg font-semibold">Now Playing</h3>
                <Badge
                  variant="secondary"
                  className="bg-stream-100 text-stream-800"
                >
                  {streamType.toUpperCase()}
                </Badge>
              </div>

              {isPlaying && (
                <div className="flex items-center gap-1">
                  <Waves className="h-4 w-4 text-stream-500 animate-pulse" />
                  <span className="text-sm text-muted-foreground">Live</span>
                </div>
              )}
            </div>

            {/* Video Player */}
            {streamType === "video" && (
              <div className="relative aspect-video bg-black rounded-lg overflow-hidden">
                <video
                  ref={videoRef}
                  className="w-full h-full"
                  onTimeUpdate={handleTimeUpdate}
                  onLoadedMetadata={handleTimeUpdate}
                  controls={false}
                />
              </div>
            )}

            {/* Audio Player Visualization */}
            {streamType === "audio" && isPlaying && (
              <div className="flex items-center justify-center h-32 bg-gradient-to-r from-stream-50 to-ocean-50 rounded-lg">
                <div className="flex items-end space-x-1 h-16">
                  {Array.from({ length: 12 }).map((_, i) => (
                    <div
                      key={i}
                      className={cn(
                        "bg-gradient-to-t from-stream-500 to-ocean-500 w-2 rounded-full animate-pulse",
                        `h-${Math.floor(Math.random() * 12) + 4}`,
                      )}
                      style={{
                        animationDelay: `${i * 0.1}s`,
                        height: `${Math.random() * 60 + 20}px`,
                      }}
                    />
                  ))}
                </div>
              </div>
            )}

            {/* Controls */}
            <div className="space-y-4">
              {/* Progress Bar */}
              {duration > 0 && (
                <div className="space-y-2">
                  <div className="w-full bg-muted rounded-full h-2">
                    <div
                      className="bg-gradient-to-r from-stream-500 to-ocean-500 h-full rounded-full transition-all duration-300"
                      style={{ width: `${(currentTime / duration) * 100}%` }}
                    />
                  </div>
                  <div className="flex justify-between text-xs text-muted-foreground">
                    <span>{formatTime(currentTime)}</span>
                    <span>{formatTime(duration)}</span>
                  </div>
                </div>
              )}

              {/* Volume Control */}
              <div className="flex items-center gap-4">
                <Button
                  variant="ghost"
                  size="sm"
                  onClick={toggleMute}
                  className="text-muted-foreground hover:text-foreground"
                >
                  {isMuted || volume[0] === 0 ? (
                    <VolumeX className="h-4 w-4" />
                  ) : (
                    <Volume2 className="h-4 w-4" />
                  )}
                </Button>

                <div className="flex-1 max-w-32">
                  <Slider
                    value={volume}
                    onValueChange={handleVolumeChange}
                    max={100}
                    step={1}
                    className="w-full"
                  />
                </div>

                <span className="text-xs text-muted-foreground w-8">
                  {volume[0]}%
                </span>
              </div>
            </div>
          </div>
        </Card>
      )}

      {/* Hidden Audio Element */}
      <audio
        ref={audioRef}
        onTimeUpdate={handleTimeUpdate}
        onLoadedMetadata={handleTimeUpdate}
        className="hidden"
      />
    </div>
  );
};
