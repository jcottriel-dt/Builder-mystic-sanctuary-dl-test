import { Link } from "react-router-dom";
import { Button } from "@/components/ui/button";
import {
  Card,
  CardContent,
  CardDescription,
  CardHeader,
  CardTitle,
} from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import {
  ArrowRight,
  Eye,
  ShoppingCart,
  CreditCard,
  Search,
  CheckCircle,
  Zap,
  Shield,
  Target,
  BookOpen,
} from "lucide-react";

const quickStartCode = `// Basic data layer initialization
window.dataLayer = window.dataLayer || [];

// Clear previous data and push page view
dataLayer.push({ 
  page_data: null, 
  event_data: null, 
  user_data: null 
});

dataLayer.push({
  event: "page_view",
  detailed_event: "Page View",
  event_data: {
    name: "home",
    identifier: "pv_home_001"
  },
  page_data: {
    page_name: "Homepage",
    page_type: "home",
    site_section: "main"
  }
});`;

const features = [
  {
    icon: CheckCircle,
    title: "GA4 Compliant",
    description:
      "All schemas follow Google Analytics 4 best practices and requirements",
  },
  {
    icon: Zap,
    title: "Production Ready",
    description:
      "Battle-tested schemas used in high-traffic ecommerce environments",
  },
  {
    icon: Shield,
    title: "Privacy Focused",
    description:
      "Designed with user privacy and data protection regulations in mind",
  },
  {
    icon: Target,
    title: "Conversion Optimized",
    description: "Track the metrics that matter most for ecommerce success",
  },
];

const popularEvents = [
  {
    name: "Page View",
    href: "/page-view",
    icon: Eye,
    description: "Track page and virtual page views across your site",
    usage: "Essential",
  },
  {
    name: "Add to Cart",
    href: "/add-to-cart",
    icon: ShoppingCart,
    description: "Monitor cart additions and abandoned cart behavior",
    usage: "High",
  },
  {
    name: "Purchase",
    href: "/purchase",
    icon: CreditCard,
    description: "Track completed transactions and revenue data",
    usage: "Critical",
  },
  {
    name: "Search",
    href: "/search",
    icon: Search,
    description: "Analyze site search behavior and query performance",
    usage: "Medium",
  },
];

export default function Index() {
  return (
    <div className="space-y-12">
      {/* Hero Section */}
      <div className="text-center space-y-6">
        <div className="space-y-2">
          <Badge variant="secondary" className="mb-4">
            GTM & GA4 Schema Reference
          </Badge>
          <h1 className="text-4xl font-bold tracking-tight sm:text-6xl">
            Ecommerce Data Layer
            <span className="text-primary block">Schema Documentation</span>
          </h1>
          <p className="text-xl text-muted-foreground max-w-2xl mx-auto">
            Comprehensive, production-ready data layer schemas for Google Tag
            Manager and Google Analytics 4. Build better tracking, make
            data-driven decisions.
          </p>
        </div>
        <div className="flex items-center justify-center gap-4">
          <Button asChild size="lg">
            <Link to="/page-view">
              Get Started
              <ArrowRight className="ml-2 h-4 w-4" />
            </Link>
          </Button>
          <Button variant="outline" size="lg" asChild>
            <Link to="/gtm-setup">GTM Setup Guide</Link>
          </Button>
        </div>
      </div>

      {/* Features */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
        {features.map((feature) => (
          <Card key={feature.title} className="text-center">
            <CardHeader>
              <feature.icon className="w-8 h-8 mx-auto text-primary mb-2" />
              <CardTitle className="text-lg">{feature.title}</CardTitle>
            </CardHeader>
            <CardContent>
              <CardDescription>{feature.description}</CardDescription>
            </CardContent>
          </Card>
        ))}
      </div>

      {/* Quick Start */}
      <div className="space-y-6">
        <div className="text-center space-y-2">
          <h2 className="text-3xl font-bold">Quick Start</h2>
          <p className="text-muted-foreground">
            Get up and running with your first data layer event in minutes
          </p>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-2 gap-8 items-start">
          <div className="space-y-4">
            <h3 className="text-xl font-semibold">Basic Implementation</h3>
            <p className="text-muted-foreground">
              Every page should start with a data layer initialization and page
              view event. This ensures clean data collection and proper event
              sequencing.
            </p>
            <div className="space-y-2">
              <div className="flex items-center text-sm text-muted-foreground">
                <CheckCircle className="w-4 h-4 mr-2 text-green-500" />
                Initialize data layer array
              </div>
              <div className="flex items-center text-sm text-muted-foreground">
                <CheckCircle className="w-4 h-4 mr-2 text-green-500" />
                Clear previous page data
              </div>
              <div className="flex items-center text-sm text-muted-foreground">
                <CheckCircle className="w-4 h-4 mr-2 text-green-500" />
                Push page view event
              </div>
            </div>
          </div>

          <div className="relative">
            <div className="flex items-center justify-between px-4 py-2 bg-muted border border-b-0 rounded-t-lg">
              <span className="text-sm font-medium text-foreground">
                JavaScript Implementation
              </span>
            </div>
            <pre className="overflow-x-auto p-4 bg-slate-900 text-slate-100 text-sm rounded-b-lg">
              <code>{quickStartCode}</code>
            </pre>
          </div>
        </div>
      </div>

      {/* Popular Events */}
      <div className="space-y-6">
        <div className="text-center space-y-2">
          <h2 className="text-3xl font-bold">Popular Events</h2>
          <p className="text-muted-foreground">
            The most commonly implemented ecommerce tracking events
          </p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
          {popularEvents.map((event) => (
            <Card
              key={event.name}
              className="group hover:shadow-md transition-shadow"
            >
              <CardHeader>
                <div className="flex items-center justify-between">
                  <div className="flex items-center space-x-3">
                    <div className="w-10 h-10 rounded-lg bg-primary/10 flex items-center justify-center">
                      <event.icon className="w-5 h-5 text-primary" />
                    </div>
                    <div>
                      <CardTitle className="text-lg">{event.name}</CardTitle>
                      <Badge variant="outline" className="text-xs">
                        {event.usage} Usage
                      </Badge>
                    </div>
                  </div>
                  <ArrowRight className="w-4 h-4 text-muted-foreground group-hover:text-foreground transition-colors" />
                </div>
              </CardHeader>
              <CardContent>
                <CardDescription className="mb-4">
                  {event.description}
                </CardDescription>
                <Button
                  variant="ghost"
                  className="w-full justify-start p-0 h-auto"
                  asChild
                >
                  <Link to={event.href}>
                    View Documentation
                    <ArrowRight className="ml-2 h-3 w-3" />
                  </Link>
                </Button>
              </CardContent>
            </Card>
          ))}
        </div>
      </div>

      {/* Getting Started */}
      <div className="bg-muted rounded-lg p-8 text-center space-y-4">
        <h2 className="text-2xl font-bold">Ready to Get Started?</h2>
        <p className="text-muted-foreground max-w-2xl mx-auto">
          Choose your implementation path: start with the essential page view
          event, or dive into the complete GTM setup guide for a comprehensive
          implementation.
        </p>
        <div className="flex items-center justify-center gap-4">
          <Button asChild>
            <Link to="/page-view">
              Start with Page View
              <ArrowRight className="ml-2 h-4 w-4" />
            </Link>
          </Button>
          <Button variant="outline" asChild>
            <Link to="/gtm-setup">Complete Setup Guide</Link>
          </Button>
        </div>
      </div>
    </div>
  );
}
