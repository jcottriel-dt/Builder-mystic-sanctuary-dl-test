import { createRoot } from "react-dom/client";
import App from "./App.tsx";
// import "./index.css"; // Temporarily disabled due to PostCSS issues

createRoot(document.getElementById("root")!).render(<App />);
